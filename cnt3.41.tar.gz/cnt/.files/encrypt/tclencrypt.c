#include <stdio.h>
#include "encrypt.h"

int main(int argc, char **argv)
{
	char _kxbyz2 [9];
	char  buf[1024], *temps;
        
	FILE *f, *f2;

        if(argc < 3)
	{
	  printf("Usage, %s infile outfile\n",argv[0]);
	  return 0;
 	}

 	f  = fopen(argv[1], "r");
 	if(!f)
	{
	  printf("Unable to open input file %s\n", argv[1]);
	  return 0;
	}

	f2 = fopen(argv[2], "w");
	if(!f2)
 	{
	  printf("Unable to open output file %s\n", argv[2]);
	  return 0;
	}

	_kxbyz2[0] = TCLSUPERFLY[0];
        _kxbyz2[1] = TCLSUPERFLY[1];
        _kxbyz2[2] = TCLSUPERFLY[2];
        _kxbyz2[3] = TCLSUPERFLY[3];
        _kxbyz2[4] = TCLSUPERFLY[4];
        _kxbyz2[5] = TCLSUPERFLY[5];
        _kxbyz2[6] = TCLSUPERFLY[6];
        _kxbyz2[7] = TCLSUPERFLY[7];
        _kxbyz2[8] = TCLSUPERFLY[8];
	_kxbyz2[9] = 0;

	while (fscanf(f,"%[^\n]\n",buf) != EOF) {
	  temps = (char *) oencrypt_string(_kxbyz2, buf);
	  fprintf(f2, "%s\n", cryptit(temps));
 	  free(temps);
	}
	fclose(f);
	fclose(f2);
	printf("file %s now encrypted as %s\n", argv[1], argv[2]);
}
