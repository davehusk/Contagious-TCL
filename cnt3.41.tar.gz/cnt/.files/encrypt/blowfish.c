#include "../src/blowfish_conf.h"
#include "../src/bf_conf_tab.h"
#include "../src/salt.h"
#include "encrypt.h"
#define oBOXES  3

/* #define S(x,i) (obf_S[i][x.w.byte##i])  */
#define oS0(x) (obf_S[0][x.w.byte0])
#define oS1(x) (obf_S[1][x.w.byte1])
#define oS2(x) (obf_S[2][x.w.byte2])
#define oS3(x) (obf_S[3][x.w.byte3])
#define obf_F(x) (((oS0(x) + oS1(x)) ^ oS2(x)) + oS3(x))
#define oROUND(a,b,n) (a.word ^= obf_F(b) ^ obf_P[n])

struct oldbox_t
  {
    UWORD_32bits *P;
    UWORD_32bits **S;
    char key[81];
    char keybytes;
  }
obox[oBOXES];


UWORD_32bits *obf_P;

UWORD_32bits **obf_S;

void 
oblowfish_encipher (UWORD_32bits * xl, UWORD_32bits * xr)
{
  union aword Xl;
  union aword Xr;

  Xl.word = *xl;
  Xr.word = *xr;

  Xl.word ^= obf_P[0];
  oROUND (Xr, Xl, 1);
  oROUND (Xl, Xr, 2);
  oROUND (Xr, Xl, 3);
  oROUND (Xl, Xr, 4);
  oROUND (Xr, Xl, 5);
  oROUND (Xl, Xr, 6);
  oROUND (Xr, Xl, 7);
  oROUND (Xl, Xr, 8);
  oROUND (Xr, Xl, 9);
  oROUND (Xl, Xr, 10);
  oROUND (Xr, Xl, 11);
  oROUND (Xl, Xr, 12);
  oROUND (Xr, Xl, 13);
  oROUND (Xl, Xr, 14);
  oROUND (Xr, Xl, 15);
  oROUND (Xl, Xr, 16);
  Xr.word ^= obf_P[17];

  *xr = Xl.word;
  *xl = Xr.word;
}

void 
oblowfish_decipher (UWORD_32bits * xl, UWORD_32bits * xr)
{
  union aword Xl;
  union aword Xr;

  Xl.word = *xl;
  Xr.word = *xr;

  Xl.word ^= obf_P[17];
  oROUND (Xr, Xl, 16);
  oROUND (Xl, Xr, 15);
  oROUND (Xr, Xl, 14);
  oROUND (Xl, Xr, 13);
  oROUND (Xr, Xl, 12);
  oROUND (Xl, Xr, 11);
  oROUND (Xr, Xl, 10);
  oROUND (Xl, Xr, 9);
  oROUND (Xr, Xl, 8);
  oROUND (Xl, Xr, 7);
  oROUND (Xr, Xl, 6);
  oROUND (Xl, Xr, 5);
  oROUND (Xr, Xl, 4);
  oROUND (Xl, Xr, 3);
  oROUND (Xr, Xl, 2);
  oROUND (Xl, Xr, 1);
  Xr.word ^= obf_P[0];

  *xl = Xr.word;
  *xr = Xl.word;
}


void 
oblowfish_init (UBYTE_08bits * key, short keybytes, int bxtouse)
{
  int i, j, bx;
  time_t lowest;
  UWORD_32bits data;
  UWORD_32bits datal;
  UWORD_32bits datar;
  union aword temp;

  for (i = 0; i < oBOXES; i++)
    if (obox[i].P != NULL)
      {
	if ((obox[i].keybytes == keybytes) &&
	    (strncmp ((char *) (obox[i].key), (char *) key, keybytes) == 0))
	  {
	    obf_P = obox[i].P;
	    obf_S = obox[i].S;
	    return;
	  }
      }
  bx = (-1);
  for (i = 0; i < oBOXES; i++)
    {
      if (obox[i].P == NULL)
	{
	  bx = i;
	  i = oBOXES + 1;
	}
    }
  if (bx < 0)
    {

      bx = bxtouse;
      free (obox[bx].P);
      for (i = 0; i < 4; i++)
	free (obox[bx].S[i]);
      free (obox[bx].S);
    }
  obox[bx].P = (UWORD_32bits *) malloc ((obf_N + 2) * sizeof (UWORD_32bits));
  obox[bx].S = (UWORD_32bits **) malloc (4 * sizeof (UWORD_32bits *));
  for (i = 0; i < 4; i++)
    obox[bx].S[i] = (UWORD_32bits *) malloc (256 * sizeof (UWORD_32bits));
  obf_P = obox[bx].P;
  obf_S = obox[bx].S;
  obox[bx].keybytes = keybytes;
  strncpy (obox[bx].key, key, keybytes);
  for (i = 0; i < obf_N + 2; i++)
    obf_P[i] = oinitbf_P[i];
  for (i = 0; i < 4; i++)
    for (j = 0; j < 256; j++)
      obf_S[i][j] = oinitbf_S[i][j];

  j = 0;
  for (i = 0; i < obf_N + 2; ++i)
    {
      temp.word = 0;
      temp.w.byte0 = key[j];
      temp.w.byte1 = key[(j + 1) % keybytes];
      temp.w.byte2 = key[(j + 2) % keybytes];
      temp.w.byte3 = key[(j + 3) % keybytes];
      data = temp.word;
      obf_P[i] = obf_P[i] ^ data;
      j = (j + 4) % keybytes;
    }

  datal = 0x00000000;
  datar = 0x00000000;

  for (i = 0; i < obf_N + 2; i += 2)
    {
      oblowfish_encipher (&datal, &datar);

      obf_P[i] = datal;
      obf_P[i + 1] = datar;
    }

  for (i = 0; i < 4; ++i)
    {
      for (j = 0; j < 256; j += 2)
	{

	  oblowfish_encipher (&datal, &datar);

	  obf_S[i][j] = datal;
	  obf_S[i][j + 1] = datar;
	}
    }
}

char *obase64 ="./0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

int 
obase64dec (char c)
{
  int i;
  for (i = 0; i < 64; i++)
    if (obase64[i] == c)
      return i;
  return 0;
}


char *
oencrypt_string (char *key, char *str)
{
  UWORD_32bits left, right;
  char *p, *s, *dest, *d;
  int i;
  dest = (char *) malloc ((strlen (str) + 9) * 2);
  s = (char *) malloc (strlen (str) + 9);
  strcpy (s, str);
  p = s;
  while (*p)
    p++;
  for (i = 0; i < 8; i++)
    *p++ = 0;
  oblowfish_init (key, strlen (key), 0);
  p = s;
  d = dest;
  while (*p)
    {
      left = ((*p++) << 24);
      left += ((*p++) << 16);
      left += ((*p++) << 8);
      left += (*p++);
      right = ((*p++) << 24);
      right += ((*p++) << 16);
      right += ((*p++) << 8);
      right += (*p++);
      oblowfish_encipher (&left, &right);
      for (i = 0; i < 6; i++)
	{
	  *d++ = obase64[right & 0x3f];
	  right = (right >> 6);
	}
      for (i = 0; i < 6; i++)
	{
	  *d++ = obase64[left & 0x3f];
	  left = (left >> 6);
	}
    }
  *d = 0;
  free (s);
  return dest;
}

char *
odecrypt_string (char *key, char *str)
{
  UWORD_32bits left, right;
  char *p, *s, *dest, *d;
  int i;
  dest = (char *) malloc (strlen (str) + 12);
  s = (char *) malloc (strlen (str) + 12);
  strcpy (s, str);
  p = s;
  while (*p)
    p++;
  for (i = 0; i < 12; i++)
    *p++ = 0;
  oblowfish_init (key, strlen (key), 0);
  p = s;
  d = dest;
  while (*p)
    {
      right = 0L;
      left = 0L;
      for (i = 0; i < 6; i++)
	right |= (obase64dec (*p++)) << (i * 6);
      for (i = 0; i < 6; i++)
	left |= (obase64dec (*p++)) << (i * 6);
      oblowfish_decipher (&left, &right);
      for (i = 0; i < 4; i++)
	*d++ = (left & (0xff << ((3 - i) * 8))) >> ((3 - i) * 8);
      for (i = 0; i < 4; i++)
	*d++ = (right & (0xff << ((3 - i) * 8))) >> ((3 - i) * 8);
    }
  *d = 0;
  free (s);
  return dest;
}


/* STOLEN simple cipher routines from psybnc ;) */

/************************************************************************
 *   psybnc2.1, src/p_crypt.c
 *   Copyright (C) 1999 the most psychoid  and
 *                      the cool lam3rz IRC Group, IRCnet
 *			http://www.psychoid.lam3rz.de
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 1, or (at your option)
 *   any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*
 * this crypting method expires with psybnc2.1 for one-way passwords.
 * the password for proxy authorisation is from now on build by
 * blowfish, but still downwards compatible.
 */

/*
 * psyCrypt
 * this routines handle the passwordencryptions.
 * Due to the fact they need to be bidirectional-ciphered,
 * this algorithm is crackable with some effort.
 * The ciphered code is built out of 5 hashes
 * The hashes are created at compiling time.
 * Its needed to fully debug the compiled code to get the hashes.
 *
 * The needed file salt.h is created by makesalt.c, which 
 * is compiled before compiling the main bouncer.
 *
 * psyCrypt is a simple Offset-Encryption.
 *
 */

/* those are now in p_idea.c */

unsigned char *hashdot(unsigned int r);
unsigned int unhashdot(unsigned char *hash);

char crybu[2000];

char *psycrypt(char *st)
{
    char *pte;
    char *ptt;
    char *pts1,*pts2;
    char *pt;
    char *hpt;
    char hbuf[3];
    int res;
    int slen=0;
    unsigned int zn;
    unsigned int tslt1 = CODE1;
    unsigned int tslt2 = CODE2;
    int p1,p2,p3,p4,p5;
    int erg;
    int de=0;
    memset(crybu,0x0,sizeof(crybu));
    pt = crybu;
    pte = pt;
    ptt = st;
    if (*ptt=='+') {
       ptt++;
       de=1;
    } else {
       *pte++='+';
    }
    pts1 = slt1 +SA1;
    pts2 = slt2 +SA2;
    while(*ptt!=0)
    {
	if (slen>1990) break;
        if (tslt1>255 || tslt1 <0) tslt1=CODE1;
        if (tslt2>255 || tslt2 <0) tslt2=CODE2;
	if (*pts1==0) pts1=slt1;
	if (*pts2==0) pts2=slt2;
	res=0;
	if (de) {
	   hbuf[0]=*ptt++;
	   hbuf[1]=*ptt;
	   hbuf[2]=0;
	   p1=unhashdot(hbuf);              
	   p2=*pts1;p3=tslt1;p4=*pts2;p5=tslt2;
	   erg=p1-p2-p3+p4-p5;    
	   *pte=erg;
	   res=erg;
	} else {
	   p1=*ptt;p2=*pts1;p3=tslt1;p4=*pts2;p5=tslt2;
	   res=p1;
	   erg=p1+p2+p3-p4+p5;    
	   hpt=hashdot(erg);
	   *pte++=hpt[0];slen++;
	   *pte=hpt[1];
	}
	tslt1--;
	res=res/10;
	tslt2=tslt2+res;
	pte++;ptt++;pts1++;pts2++;slen=slen+1;
    } 
    *pte=0;
    return pt;
}

char *cryptit(char *tocipher)
{
    if (*tocipher=='+')
       return tocipher;
    else
       return psycrypt(tocipher);
}

char *decryptit(char *todecipher)
{
    if (todecipher[0]=='+')
	return psycrypt(todecipher);
    else
	return todecipher;
}

/* hashing routines for string driven systems */

unsigned char base[]="'`0123456789abcdefghijklmnopqrstuvxyzABCDEFGHIJKLMNOPQRSTUVWXYZ@$=&*-#";

int baselen=67;

unsigned char xres[3];

unsigned char *hashdot(unsigned int r)
{
    unsigned int cnt;
    unsigned int hh=0;
    unsigned int hl=0;
    cnt=r;
    for(;cnt>0;cnt--)
    {
	hl++;
	if (hl==baselen) {hl=0;hh++;}
    }
    xres[0]=base[hh];
    xres[1]=base[hl];
    xres[2]=0;
    return xres;
}

int wrong=0;

unsigned int unhashdot(unsigned char *hash)
{
    unsigned int lf=baselen;
    unsigned char *pt;
    unsigned int erg=0;
    unsigned long ln=0;
    wrong=0;
    while (ln<baselen && base[ln] != hash[0]) {
	ln++;
    }
    if (ln!=baselen) {
	erg=ln * lf;
    } else {
	wrong=1;
    }
    ln=0;
    while (ln<baselen && base[ln] != hash[1]) {
	ln++;
    }
    if (ln!=baselen) {
	erg=erg+ln;
    } else {
	wrong=1;
    }
    return erg;
}

/* END STOLEN */
